import logging
import os
import secrets
from typing import Annotated, Any

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field

from mem0 import Memory

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Load environment variables
load_dotenv()

ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "")

MIN_KEY_LENGTH = 16

if not ADMIN_API_KEY:
    logging.warning(
        "ADMIN_API_KEY not set - API endpoints are UNSECURED! "
        "Set ADMIN_API_KEY environment variable for production use."
    )
else:
    if len(ADMIN_API_KEY) < MIN_KEY_LENGTH:
        logging.warning(
            "ADMIN_API_KEY is shorter than %d characters - consider using a longer key for production.",
            MIN_KEY_LENGTH,
        )
    logging.info("API key authentication enabled")

POSTGRES_HOST = os.environ.get("POSTGRES_HOST", "postgres")
POSTGRES_PORT = os.environ.get("POSTGRES_PORT", "5432")
POSTGRES_DB = os.environ.get("POSTGRES_DB", "postgres")
POSTGRES_USER = os.environ.get("POSTGRES_USER", "postgres")
POSTGRES_PASSWORD = os.environ.get("POSTGRES_PASSWORD")
if not POSTGRES_PASSWORD:
    raise ValueError("POSTGRES_PASSWORD environment variable is required")
POSTGRES_COLLECTION_NAME = os.environ.get("POSTGRES_COLLECTION_NAME", "memories")

NEO4J_URI = os.environ.get("NEO4J_URI", "bolt://neo4j:7687")
NEO4J_USERNAME = os.environ.get("NEO4J_USERNAME", "neo4j")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD")
if not NEO4J_PASSWORD:
    raise ValueError("NEO4J_PASSWORD environment variable is required")

MEMGRAPH_URI = os.environ.get("MEMGRAPH_URI", "bolt://localhost:7687")
MEMGRAPH_USERNAME = os.environ.get("MEMGRAPH_USERNAME", "memgraph")
MEMGRAPH_PASSWORD = os.environ.get("MEMGRAPH_PASSWORD")
if not MEMGRAPH_PASSWORD:
    raise ValueError("MEMGRAPH_PASSWORD environment variable is required")

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
HISTORY_DB_PATH = os.environ.get("HISTORY_DB_PATH", "/app/history/history.db")

# LLM Configuration from environment
LLM_PROVIDER = os.environ.get("MEM0_LLM_PROVIDER", "openai")
LLM_BASE_URL = os.environ.get("MEM0_LLM_BASE_URL", None)
LLM_MODEL = os.environ.get("MEM0_LLM_MODEL", "gpt-4.1-nano-2025-04-14")
LLM_API_KEY = os.environ.get("MEM0_LLM_API_KEY", OPENAI_API_KEY)

# Embedder Configuration from environment
# NOTE: Mem0 uses "openai" provider but with custom base_url for openai_compatible endpoints
EMBEDDER_PROVIDER = "openai"  # Always use openai provider name for Mem0
EMBEDDER_BASE_URL = os.environ.get("EMBEDDING_BASE_URL", None) or os.environ.get("OPENAI_EMBEDDING_URL", None)
EMBEDDER_API_KEY = os.environ.get("EMBEDDING_API_KEY", OPENAI_API_KEY)
EMBEDDER_MODEL = os.environ.get("EMBEDDER_MODEL", "text-embedding-3-small")

# Build LLM config - use openai_base_url for custom endpoints
llm_config: dict[str, Any] = {"api_key": LLM_API_KEY, "temperature": 0.2, "model": LLM_MODEL}
if LLM_BASE_URL:
    llm_config["openai_base_url"] = LLM_BASE_URL

# Build embedder config - use openai_compatible endpoint via openai provider
# Use openai_base_url parameter for custom endpoints
embedder_config: dict[str, Any] = {"api_key": EMBEDDER_API_KEY, "model": EMBEDDER_MODEL}
if EMBEDDER_BASE_URL:
    embedder_config["openai_base_url"] = EMBEDDER_BASE_URL

DEFAULT_CONFIG = {
    "version": "v1.1",
    "vector_store": {
        "provider": "pgvector",
        "config": {
            "host": POSTGRES_HOST,
            "port": int(POSTGRES_PORT),
            "dbname": POSTGRES_DB,
            "user": POSTGRES_USER,
            "password": POSTGRES_PASSWORD,
            "collection_name": POSTGRES_COLLECTION_NAME,
        },
    },
    "graph_store": {"provider": "none"},
    "llm": {"provider": LLM_PROVIDER, "config": llm_config},
    "embedder": {"provider": EMBEDDER_PROVIDER, "config": embedder_config},
    "history_db_path": HISTORY_DB_PATH,
}


MEMORY_INSTANCE = Memory.from_config(DEFAULT_CONFIG)

app = FastAPI(
    title="Mem0 REST APIs",
    description=(
        "A REST API for managing and searching memories for your AI Agents and Apps.\n\n"
        "## Authentication\n"
        "When the ADMIN_API_KEY environment variable is set, all endpoints require "
        "the `X-API-Key` header for authentication."
    ),
    version="1.0.0",
)

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def verify_api_key(api_key: str | None = Depends(api_key_header)):
    """Validate the API key when ADMIN_API_KEY is configured. No-op otherwise."""
    if ADMIN_API_KEY:
        if api_key is None:
            raise HTTPException(
                status_code=401,
                detail="X-API-Key header is required.",
                headers={"WWW-Authenticate": "ApiKey"},
            )
        if not secrets.compare_digest(api_key, ADMIN_API_KEY):
            raise HTTPException(
                status_code=401,
                detail="Invalid API key.",
                headers={"WWW-Authenticate": "ApiKey"},
            )
    return api_key


class Message(BaseModel):
    role: Annotated[str, Field(description="Role of the message (user or assistant).")]
    content: Annotated[str, Field(description="Message content.")]


class MemoryCreate(BaseModel):
    messages: Annotated[list[Message], Field(description="List of messages to store.")]
    user_id: Annotated[str | None, Field(description="User identifier for the memory.")] = None
    agent_id: Annotated[str | None, Field(description="Agent identifier for the memory.")] = None
    run_id: Annotated[str | None, Field(description="Run identifier for the memory.")] = None
    metadata: Annotated[dict[str, Any] | None, Field(description="Additional metadata for the memory.")] = None
    infer: Annotated[bool | None, Field(description="Whether to extract facts from messages. Defaults to True.")] = None
    memory_type: Annotated[str | None, Field(description="Type of memory to store (e.g. 'core').")] = None
    prompt: Annotated[str | None, Field(description="Custom prompt to use for fact extraction.")] = None


class MemoryUpdate(BaseModel):
    text: Annotated[str, Field(description="New content to update the memory with.")]


class SearchRequest(BaseModel):
    query: Annotated[str, Field(description="Search query.")]
    user_id: Annotated[str | None, Field(description="User identifier to filter memories.")] = None
    run_id: Annotated[str | None, Field(description="Run identifier to filter memories.")] = None
    agent_id: Annotated[str | None, Field(description="Agent identifier to filter memories.")] = None
    filters: Annotated[dict[str, Any] | None, Field(description="Additional filters for the search.")] = None
    top_k: Annotated[int | None, Field(description="Maximum number of results to return.")] = None
    threshold: Annotated[float | None, Field(description="Minimum similarity score for results.")] = None


@app.post("/configure", summary="Configure Mem0")
def set_config(config: dict[str, Any], _api_key: Annotated[str | None, Depends(verify_api_key)] = None):
    """Set memory configuration."""
    global MEMORY_INSTANCE
    MEMORY_INSTANCE = Memory.from_config(config)
    return {"message": "Configuration set successfully"}


@app.post("/memories", summary="Create memories")
def add_memory(
    memory_create: MemoryCreate,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Store new memories."""
    if not any([memory_create.user_id, memory_create.agent_id, memory_create.run_id]):
        raise HTTPException(status_code=400, detail="At least one identifier (user_id, agent_id, run_id) is required.")

    params = {k: v for k, v in memory_create.model_dump().items() if v is not None and k != "messages"}
    try:
        response = MEMORY_INSTANCE.add(messages=[m.model_dump() for m in memory_create.messages], **params)
        return JSONResponse(content=response)
    except Exception as e:
        logging.exception("Error in add_memory:")  # This will log the full traceback
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memories", summary="Get memories")
def get_all_memories(
    user_id: str | None = None,
    run_id: str | None = None,
    agent_id: str | None = None,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Retrieve stored memories."""
    if not any([user_id, run_id, agent_id]):
        raise HTTPException(status_code=400, detail="At least one identifier is required.")
    try:
        params = {
            k: v for k, v in {"user_id": user_id, "run_id": run_id, "agent_id": agent_id}.items() if v is not None
        }
        return MEMORY_INSTANCE.get_all(**params)
    except Exception as e:
        logging.exception("Error in get_all_memories:")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memories/{memory_id}", summary="Get a memory")
def get_memory(
    memory_id: str,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Retrieve a specific memory by ID."""
    try:
        return MEMORY_INSTANCE.get(memory_id)
    except Exception as e:
        logging.exception("Error in get_memory:")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/search", summary="Search memories")
def search_memories(
    search_req: SearchRequest,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Search for memories based on a query."""
    try:
        params = {k: v for k, v in search_req.model_dump().items() if v is not None and k != "query"}
        return MEMORY_INSTANCE.search(query=search_req.query, **params)
    except Exception as e:
        logging.exception("Error in search_memories:")
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/memories/{memory_id}", summary="Update a memory")
def update_memory(
    memory_id: str,
    updated_memory: MemoryUpdate,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Update an existing memory with new content.

    Args:
        memory_id (str): ID of the memory to update
        updated_memory (MemoryUpdate): New content and optional metadata to update the memory with

    Returns:
        dict: Success message indicating the memory was updated
    """
    try:
        return MEMORY_INSTANCE.update(memory_id=memory_id, data=updated_memory.text, metadata=updated_memory.metadata)
    except Exception as e:
        logging.exception("Error in update_memory:")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memories/{memory_id}/history", summary="Get memory history")
def memory_history(
    memory_id: str,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Retrieve memory history."""
    try:
        return MEMORY_INSTANCE.history(memory_id=memory_id)
    except Exception as e:
        logging.exception("Error in memory_history:")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/memories/{memory_id}", summary="Delete a memory")
def delete_memory(
    memory_id: str,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Delete a specific memory by ID."""
    try:
        MEMORY_INSTANCE.delete(memory_id=memory_id)
        return {"message": "Memory deleted successfully"}
    except Exception as e:
        logging.exception("Error in delete_memory:")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/memories", summary="Delete all memories")
def delete_all_memories(
    user_id: str | None = None,
    run_id: str | None = None,
    agent_id: str | None = None,
    _api_key: Annotated[str | None, Depends(verify_api_key)] = None,
):
    """Delete all memories for a given identifier."""
    if not any([user_id, run_id, agent_id]):
        raise HTTPException(status_code=400, detail="At least one identifier is required.")
    try:
        params = {
            k: v for k, v in {"user_id": user_id, "run_id": run_id, "agent_id": agent_id}.items() if v is not None
        }
        MEMORY_INSTANCE.delete_all(**params)
        return {"message": "All relevant memories deleted"}
    except Exception as e:
        logging.exception("Error in delete_all_memories:")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/reset", summary="Reset all memories")
def reset_memory(_api_key: Annotated[str | None, Depends(verify_api_key)] = None):
    """Completely reset stored memories."""
    try:
        MEMORY_INSTANCE.reset()
        return {"message": "All memories reset"}
    except Exception as e:
        logging.exception("Error in reset_memory:")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/", summary="Redirect to the OpenAPI documentation", include_in_schema=False)
def home():
    """Redirect to the OpenAPI documentation."""
    return RedirectResponse(url="/docs")
